README of dist-sheet2.

Contents of this folder:
	apiDocumentation/		The folder contains the API in generated javadoc HTML files.
							Accessible through apiDocumentation/index.html
	
	metadataHandling.pdf	A file describing the handling of meta data
	
	readme.txt				This readme file
	
	timesheet.pdf			A timesheet listing how much time was spend.
	
Authors:
	Max Gr�ner,
	Silvan Heller,
	Eddie Joseph,
	Loris Sauter